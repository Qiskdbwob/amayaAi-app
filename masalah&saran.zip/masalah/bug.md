# Temuan Bug & Salah Logika

Hasil audit statis (read-only) terhadap `app/`, `amaya-remote-extension/`, dan `windows-bridge/` pada branch `main`.
Setiap item menyebutkan lokasi file, dampak, dan arah perbaikan. Prioritas: **P1** (harus segera), **P2** (penting), **P3** (perapian).

---

## P1 — Logika keamanan shell

### 1. Pola *Trusted Commands* dengan `*` melintasi pemisah shell (`;`, `&&`, `||`, `|`)
- **File**: `app/src/main/java/com/amaya/intelligence/data/repository/TerminalSettingsRepository.kt` (`commandMatchesWildcard`, `DEFAULT_TRUSTED_COMMANDS`) dan `domain/security/CommandValidator.kt` (`validateCommand`).
- **Masalah**: `*` diterjemahkan menjadi regex `.*`, sehingga `ls *`, `cat *`, `grep *`, `find *` (default) cocok dengan perintah berantai. `validateCommand` memeriksa trusted **sebelum** klasifikasi destruktif, jadi perintah berikut lolos tanpa konfirmasi:
  - `ls && rm -rf ./src`
  - `cat README.md; git push --force`
  - `find . -type f -delete` / `find . -exec rm {} +`
- **Dampak**: penghapusan/overwrite di dalam workspace tanpa prompt persetujuan. `HARD_BLOCK_PATTERNS` hanya menahan `rm -rf /`.
- **Perbaikan**: (a) pecah perintah per segmen (`;`, `&&`, `||`, `|`, `\n`, `&`) dan wajibkan **setiap** segmen cocok pola trusted; (b) terjemahkan `*` menjadi `[^;&|\n]*`; (c) jalankan `NON_DESTRUCTIVE_DANGEROUS_VERBS` + `isEffectfulGitCommand` bahkan untuk perintah trusted, atau minimal untuk segmen selain segmen pertama.

### 2. Sandbox aktif di setting tetapi PRoot tidak tersedia → perintah jalan di host shell tanpa pembatasan workspace
- **File**: `CommandValidator.validateToolCall` (`if (!terminalSettings.useLinuxSandbox)`), `tools/RunShellTool.kt` (`isSandboxActive = settings.useLinuxSandbox && linuxSandboxManager.isReady()`), `domain/sandbox/LinuxSandboxManager.kt` (`buildExecutionArgs` → `prootPath == null` → `/system/bin/sh -c`).
- **Masalah**: `isReady()` hanya memeriksa rootfs (`bin/busybox`), bukan ketersediaan PRoot. Pada x86 (tidak ada `libproot.so`/static build) atau saat unduhan PRoot gagal, perintah dieksekusi di host shell, sementara validator **melewati** `shellWorkspaceViolation` karena `useLinuxSandbox == true`.
- **Dampak ganda**: (1) AI bisa keluar dari workspace via `cd`/path absolut; (2) `buildExecutionEnv` memaksa `PATH=/usr/local/sbin:...:/bin` tanpa `/system/bin`, sehingga di host semua perintah gagal `not found`.
- **Perbaikan**: satukan definisi "sandbox aktif" di satu tempat (`LinuxSandboxManager.isExecutable(): Boolean = isReady() && prootAvailable`) dan gunakan hasil yang sama di validator dan tool. Jika PRoot tidak ada, **tolak** perintah atau jalankan di host dengan containment + env host.

### 3. Klasifikasi *non-destructive* (auto-approve default ON) menganggap interpreter dan package manager sebagai aman
- **File**: `CommandValidator.isNonDestructiveCommand`, `NON_DESTRUCTIVE_DANGEROUS_VERBS`.
- **Masalah**: tidak ada `python|python3|node|perl|ruby|php|sh|bash|ash|eval|source|xargs|cp|install|patch|sed -i|perl -i|npm|npx|pip|apk|gradle|make|git clone`. Contoh yang lolos tanpa prompt:
  - `python3 -c "import shutil;shutil.rmtree('src')"`
  - `sed -i 's/x/y/g' build.gradle.kts`
  - `cp -r a b` (overwrite), `npm install` (postinstall script arbitrer), `apk add ...`
- **Perbaikan**: tambahkan interpreter/package manager ke daftar *requires review*; deteksi flag in-place (`sed -i`, `perl -i`); atau balik ke pendekatan allowlist murni sesuai prinsip "Whitelist over Blacklist" yang ditulis di header kelas tetapi tidak diimplementasikan.

### 4. `shellWorkspaceViolation` hanya memeriksa path absolut dan `cd`
- **File**: `CommandValidator.shellWorkspaceViolation`.
- **Celah**: path relatif `../../` (`cat ../../../etc/hosts`), `~`, `$HOME`, `${PWD}/..`, `cd<TAB>/tmp` (hanya `startsWith("cd ")`), `pushd`, `cd -`, pemisah `&` tunggal dan newline tidak dipecah, `git -C ../lain`.
- **Perbaikan**: resolve semua token yang mengandung `/` atau `..` relatif terhadap root; tolak `~`, `$HOME`, ekspansi variabel; split dengan regex yang sama seperti `isEffectfulGitCommand` plus `\n` dan `&`.

### 5. `validatePath` menolak nama file legal yang mengandung `..`
- **File**: `CommandValidator.containsPathTraversal` (`path.contains("..")`).
- **Masalah**: `notes..md`, `..config`, `a..b/` ditolak sebagai *traversal*. `WorkspacePathResolver` sudah memeriksa per segmen (benar). Dua aturan berbeda untuk konsep yang sama.
- **Perbaikan**: gunakan pemeriksaan per segmen (`split('/').any { it == ".." }`) di kedua tempat, atau hapus pemeriksaan di validator karena path sudah host-resolved.

---

## P2 — Agent loop & tool executor

### 6. `rejectedToolCalls` tidak pernah diisi → dua blok feedback adalah *dead code*
- **File**: `data/repository/AiAgentLoop.kt` (deklarasi `val rejectedToolCalls = mutableListOf<ToolCallMessage>()`, dua blok `if (rejectedToolCalls.isNotEmpty())`).
- **Masalah**: tool call yang tidak dikenali/duplikat justru dimasukkan ke `toolCalls` dan `invalidToolArgumentErrors`, sehingga `hasToolCalls = true` dan `AgentEvent.ToolCallStart` dikirim untuk tool yang **tidak ada** (UI menampilkan kartu tool palsu). Log `TOOL_CALL_REJECTED_FEEDBACK` tidak pernah terpicu.
- **Perbaikan**: hapus `rejectedToolCalls` atau isi dengan benar dan jangan kirim `ToolCallStart` untuk call yang ditolak.

### 7. `failedToolAttempts` kumulatif, bukan *consecutive* seperti pesan error
- **File**: `AiAgentLoop.kt` (`MAX_FAILED_TOOL_ATTEMPTS`).
- **Masalah**: tidak direset ketika ada tool call valid yang sukses, sehingga turn panjang bisa dihentikan karena 3 kesalahan yang tersebar. Pesan `"... consecutive invalid tool calls"` menyesatkan.
- **Perbaikan**: reset counter saat batch tool call berhasil dieksekusi, atau ubah pesan menjadi kumulatif.

### 8. ID sintetis `synth_call_${System.currentTimeMillis()}` bisa bertabrakan
- **File**: `AiAgentLoop.kt`.
- **Masalah**: dua tool call tanpa ID dalam milidetik yang sama dianggap *duplicate ID* dan ditolak. Gunakan `UUID.randomUUID()`.

### 9. `validateToolArguments` dipanggil dua kali untuk call yang sama
- **File**: `AiAgentLoop.kt` (blok `ChatResponse.ToolCall`).
- **Perbaikan**: simpan hasil validasi pertama dan pakai ulang.

### 10. `RunShellTool` — catch tidak terjangkau dan data race kecil
- **File**: `tools/RunShellTool.kt`.
- `catch (e: TimeoutCancellationException)` setelah `catch (CancellationException)` tidak pernah tercapai (subclass) dan `withTimeout` sudah dihapus → hapus.
- `truncated` (`var` non-volatile) dan `output` (`StringBuilder`) ditulis di reader thread dan dibaca setelah `join(2_000)`; jika join timeout, pembacaan adalah data race dan output terpotong diam-diam.
- `terminalSettingsRepository.getSettings()` dipanggil dua kali (di `execute` dan `runCommand`) → bisa inkonsisten.
- Deskripsi tool ke model: "validated against a security **whitelist**" padahal blacklist; menyesatkan model.

### 11. `ToolExecutor` — fail-open, komentar salah, dan kerja berulang
- **File**: `tools/ToolExecutor.kt`.
- `assistantModeAllowsCapability(AGENT)`: `agentCapabilityProfile?.allows(name) ?: true` → jika profil null, **semua** tool diizinkan (bertentangan dengan prinsip *fail secure*).
- `desanitizeBridgeToolName` adalah fungsi identitas; komentar menyebut `'.' → '__'` tetapi kode `'.' → '_'`.
- `normalizeIntegerArguments` memanggil `getToolDefinitions(AssistantMode.AGENT)` (membangun semua definisi) pada **setiap** tool call.
- `run_shell` divalidasi dua kali: `validateToolCall → validateCommand` lalu `RunShellTool.execute → validateCommand` lagi.

---

## P2 — Sandbox, penyimpanan, DB

### 12. Zip-Slip check tanpa pemisah direktori
- **File**: `LinuxSandboxManager.extractTarGz`: `targetFile.canonicalPath.startsWith(destDir.canonicalPath)`.
- **Masalah**: `/data/.../alpine` cocok dengan `/data/.../alpine2/...`. Tambahkan `+ File.separator` (atau bandingkan `destDir.canonicalPath == parent`).

### 13. Fallback plaintext untuk API key tidak dikecualikan dari backup
- **File**: `data/remote/api/AiSettings.kt` (`createEncryptedPrefs` → `amaya_secure_prefs_fallback`), `res/xml/backup_rules.xml`, `res/xml/data_extraction_rules.xml`.
- **Masalah**: kedua file backup hanya meng-exclude `amaya_secure_prefs.xml` dan keyset. `amaya_secure_prefs_fallback.xml` (berisi API key **plaintext**) ikut `<include domain="sharedpref" path="."/>` → dapat naik ke cloud backup / device transfer.
- **Perbaikan**: tambahkan exclude untuk `amaya_secure_prefs_fallback.xml`, atau lebih baik jangan pernah menyimpan kredensial plaintext (tampilkan error dan minta pengguna memasukkan ulang).

### 14. Migrasi Room mulai dari v5
- **File**: `data/local/db/AppDatabase.kt`.
- **Masalah**: tidak ada `MIGRATION_1..4` maupun `fallbackToDestructiveMigrationFrom(1,2,3,4)`. Perangkat dengan DB versi < 5 akan crash saat buka.

### 15. `LinuxArchitecture.detect()` fallback ke `AARCH64`
- **File**: `domain/sandbox/LinuxArchitecture.kt`.
- Jika `SUPPORTED_ABIS` kosong/tidak dikenal, mengunduh rootfs arm64 di perangkat yang bukan arm64. Sebaiknya kembalikan `null`/error eksplisit.

### 16. `jniLibs/x86` tidak lengkap
- **Path**: `app/src/main/jniLibs/x86/` hanya berisi `libproot_loader.so` (tanpa `libproot.so`); `splits.abi` hanya `armeabi-v7a`/`arm64-v8a`.
- Loader x86 ikut ke APK universal tanpa fungsi. Hapus atau lengkapi.

### 17. `McpClientManager` constructor `@Inject` dengan parameter nullable + default
- **File**: `data/remote/mcp/McpClientManager.kt` (`settingsManager: AiSettingsManager? = null`).
- Hilt selalu menyuntikkan non-null; nullability dan `?:` di seluruh kelas adalah jalur yang tidak pernah dieksekusi di produksi.

### 18. `AiSettingsManager.init` membuat `CoroutineScope(Dispatchers.IO)` tanpa lifecycle
- Scope tidak pernah dibatalkan; `getSettings()` memakai `runBlocking` (import ada) → potensi blok main thread saat cache belum hangat.

---

## P3 — Extension & Windows Bridge

### 19. `command-policy.ts` memakai `includes()` substring
- **File**: `windows-bridge/src/permissions/command-policy.ts`.
- `blockedCommands: ['rm','del','format','reg',...]` memblokir `regex`, `region`, `alarm`, `perform`, `model`. Sebaliknya `Remove-Item`, `rd`, `erase` tidak diblokir. Gunakan tokenisasi + word boundary.

### 20. Ekstensi VS Code — ID sesi & debounce
- **File**: `amaya-remote-extension/src/controllers/MessageHandler.ts`.
- `serverSessionId` memakai `Math.random()` (bukan kriptografis) — cukup untuk ID sesi, tetapi jangan dipakai untuk token.

---

## Ringkasan prioritas

| # | Judul | Prioritas |
|---|-------|-----------|
| 1 | Wildcard trusted melintasi `;`/`&&` | P1 |
| 2 | Sandbox ON tanpa PRoot → host shell tanpa containment | P1 |
| 3 | Interpreter dianggap non-destruktif | P1 |
| 4 | Containment hanya path absolut/`cd` | P1 |
| 13 | API key plaintext ikut backup | P2 |
| 6, 7, 8 | Dead code & counter di AiAgentLoop | P2 |
| 12 | Zip-Slip prefix | P2 |
| 11 | Fail-open agent capability | P2 |
