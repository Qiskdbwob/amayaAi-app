# Temuan Error (Build, Konfigurasi, Runtime)

Item di sini adalah hal yang **sudah** atau **akan** menghasilkan error nyata (build gagal, runtime exception, pipeline tidak berjalan), bukan sekadar salah logika.

---

## Build & CI

### E1. Tidak ada `.gitlab-ci.yml` — pipeline GitLab tidak berjalan
- Repo ini di-mirror ke GitLab (`import_url` GitHub), tetapi satu-satunya CI adalah `.github/workflows/android-ci.yml`. Di GitLab tidak ada job build/test/lint apa pun.
- **Perbaikan**: tambahkan `.gitlab-ci.yml` (lihat `saran/improvement.md`), minimal `assemblePerf` + `testPerfUnitTest` + SAST/Secret Detection template.

### E2. `gradle-wrapper.jar` tidak di-commit dan diunduh dari `master`
- **File**: `.github/workflows/android-ci.yml` (step *Ensure Gradle Wrapper*), `.gitignore` (`*.jar` dengan `!gradle/wrapper/gradle-wrapper.jar`), tree hanya berisi `gradle-wrapper.properties`.
- **Masalah**: `curl https://raw.githubusercontent.com/gradle/gradle/master/gradle/wrapper/gradle-wrapper.jar` mengambil jar dari branch bergerak. Versi jar dapat tidak cocok dengan `distributionUrl`, build tidak reprodusibel, dan merupakan risiko supply-chain (tidak ada checksum).
- **Perbaikan**: commit `gradle-wrapper.jar` (sudah di-whitelist di `.gitignore`) dan gunakan `gradle/actions/wrapper-validation`, atau pakai `setup-gradle` dengan `gradle-version` eksplisit.

### E3. Versi dependency hardcoded di luar version catalog dan saling tidak cocok
- **File**: `app/build.gradle.kts` vs `gradle/libs.versions.toml`.
  - `org.jetbrains.kotlin:kotlin-test:2.0.0` vs Kotlin plugin `2.0.21` → potensi konflik stdlib pada unit test.
  - `kotlinx-coroutines-test:1.8.1` vs `coroutines = 1.9.0`.
  - `androidx.security:security-crypto:1.1.0-alpha06` (alpha di produksi; ada rilis stabil `1.1.0`).
  - `androidx.work:work-runtime-ktx:2.9.1`, `androidx.hilt:hilt-work:1.2.0`, `appcompat:1.7.0`, `Java-WebSocket:1.5.7`, `commons-compress:1.26.0`, `geckoview-omni:152.*` semuanya hardcoded.
- **Perbaikan**: pindahkan semua ke `libs.versions.toml`; aktifkan Renovate/Dependabot.

### E4. `targetSdk = 28` — konsekuensi yang perlu didokumentasikan sebagai *known error*
- Alasannya valid (W^X untuk PRoot), tetapi menyebabkan: peringatan "dibuat untuk Android versi lama" saat install di Android 14+, `POST_NOTIFICATIONS` tidak diminta secara eksplisit (sistem yang prompt), izin `FOREGROUND_SERVICE_SPECIAL_USE` dan `POST_PROMOTED_NOTIFICATIONS` (API 34/36) tidak berpengaruh. `tools:targetApi="34"` di manifest tidak konsisten dengan `targetSdk 28`.
- Alternatif: bundel semua binari yang perlu di-exec sebagai `jniLibs` (sudah dilakukan untuk PRoot) sehingga `targetSdk` dapat dinaikkan; hanya rootfs Alpine yang di-exec **melalui** PRoot, bukan langsung.

### E5. Izin tidak terpakai di `AndroidManifest.xml`
- `BLUETOOTH_SCAN/CONNECT/ADVERTISE`, `BLUETOOTH`, `BLUETOOTH_ADMIN` dideklarasikan ("for sync") tetapi tidak ada kode Bluetooth di tree. Hapus untuk mengurangi permukaan izin.

---

## Runtime

### E6. Host-shell fallback dengan `PATH` Linux
- **File**: `LinuxSandboxManager.buildExecutionEnv` dipakai bersama `buildExecutionArgs(prootPath = null)` → `/system/bin/sh` dijalankan dengan `PATH=/usr/local/sbin:...:/bin` (tanpa `/system/bin`, `/system/xbin`).
- Semua perintah (`ls`, `grep`, `git`) gagal `not found` ketika sandbox dinyalakan tetapi PRoot tidak ada (lihat `masalah/bug.md` #2).

### E7. File I/O saat konstruksi singleton Hilt
- `LinuxSandboxManager.init { checkStatus() }` dan `AiSettingsManager` (lazy `encryptedPrefs`, `startupPrefs`) melakukan I/O disk saat graf Hilt dibangun, sering di main thread saat Activity pertama → StrictMode violation / jank / ANR di perangkat lambat.

### E8. Room tanpa jalur migrasi untuk versi < 5
- Crash `IllegalStateException: A migration from 4 to 17 was required but not found`. Tambahkan `fallbackToDestructiveMigrationFrom(1, 2, 3, 4)` bila versi lama memang tidak pernah dirilis.

### E9. `OkHttpClient.retryOnConnectionFailure(true)` pada request streaming POST
- Request chat (POST, body non-idempoten) dapat diulang otomatis oleh OkHttp setelah kegagalan koneksi tertentu → double billing / dua respons. Untuk klien provider, set `retryOnConnectionFailure(false)` dan tangani retry di layer aplikasi.

---

## Repositori & dokumentasi

### E10. `LICENSE` dan `AGENTS.md` root **kosong**
- Blob `e69de29b...` (0 byte) untuk `LICENSE` dan `AGENTS.md` di root. README menyatakan Apache-2.0 dan meminta kontributor membaca `AGENTS.md`. Isi file lisensi penuh dan pindahkan/rangkum aturan root.

### E11. Referensi ke dokumen yang di-ignore
- `app/AGENTS.md` merujuk `docs/local/audits/VISION-HOLD.md` dan `ANDROID-FILETREE-LINE-MAP.md`, tetapi `docs/local/` ada di `.gitignore` → tautan mati bagi kontributor lain.

### E12. Fixture pengujian berisi data personal dan file sementara
- `amaya-remote-extension/test/antigravity/extension-server/models/user-status-response.json` berisi nama dan alamat email nyata.
- File scratch ter-commit: `tmp_check_ip.js`, `tmp-client.js`, `tmp_test_models.js`, `raw-cortex-capture copy.json`, `walkthrough.md.resolved`, dump trajektori mentah berukuran besar.
- **Perbaikan**: anonimkan fixture, hapus file `tmp*`, pertimbangkan `git filter-repo` untuk riwayat.

### E13. `.gitignore` berisi nama file scratch spesifik
- `AGENTSuhybvjh.md`, `jnkedf.txt`, `sdfvb.txt`, `hello_amaya.py`, dst. Gunakan direktori `scratch/` atau `.git/info/exclude` lokal.

### E14. Komentar `FIX 1..5.x` di kode
- Banyak komentar `// FIX 3.10`, `// FIX 4.6` merujuk nomor audit internal yang tidak ada di repo. Ganti dengan penjelasan *mengapa* atau tautan issue.
