# Temuan Keamanan

Dikelompokkan per komponen. Beberapa item juga muncul di `bug.md` karena akar masalahnya adalah salah logika.

---

## Android (`app/`)

### K1. Eskalasi melalui *Trusted Commands* berantai — **Tinggi**
Lihat `masalah/bug.md` #1. `ls && rm -rf ./` lolos tanpa prompt karena `ls *` adalah pola default.

### K2. Sandbox "aktif" tanpa PRoot → host shell tanpa containment — **Tinggi**
Lihat `masalah/bug.md` #2.

### K3. Auto-approve default ON untuk interpreter/package manager — **Tinggi**
Lihat `masalah/bug.md` #3. `python -c`, `node -e`, `sh x.sh`, `npm install`, `pip install` dianggap non-destruktif.

### K4. Celah pada `HARD_BLOCK_PATTERNS`
- **File**: `domain/security/CommandValidator.kt`.
- `| sh` diblokir, tetapi `sh -c "..."`, `bash script.sh`, `eval`, `source`, `. ./x.sh` tidak.
- `chmod 777|+s` diblokir, tetapi `chmod 0777`, `chmod a+rwx`, `chmod u+s`, `chmod -R 777` (spasi ganda) tidak.
- `dd of=/dev/` diblokir, tetapi `cat x > /dev/block/...` hanya sebagian tertangkap.
- Penanda `>` untuk *write* juga menandai `2>&1` (false positive → prompt berlebihan; membuat pengguna terbiasa klik *Approve*).

### K5. Unduhan rootfs Alpine & PRoot tanpa verifikasi integritas — **Sedang**
- **File**: `domain/sandbox/LinuxSandboxManager.kt` (`downloadFileWithProgress`, `setupProotBinary`), `LinuxArchitecture.kt`.
- Tidak ada pengecekan SHA-256 (Alpine mempublikasikan `.sha256` di direktori yang sama) maupun pin ukuran/tanda tangan untuk PRoot dari GitHub Releases. Mirror yang disusupi = eksekusi kode di perangkat pengguna.
- `runApkAdd` menambahkan fallback mirror **HTTP** (`http://dl-cdn.alpinelinux.org`). `apk` memverifikasi tanda tangan paket, tetapi index bisa di-downgrade oleh MITM.
- **Perbaikan**: pin hash rootfs per versi/arsitektur di kode; verifikasi sebelum ekstraksi; hapus mirror HTTP.

### K6. Injeksi argumen pada `runApkAdd(packageName)` — **Sedang**
- `"apk ... add --no-cache $targetPackages"` diinterpolasi langsung ke `sh -c`. Jika `packageName` datang dari model/pengguna (`apk add git; rm -rf /workspace`) → eksekusi perintah tambahan di dalam sandbox. Validasi dengan regex `^[a-z0-9._+-]+( [a-z0-9._+-]+)*$` atau kirim sebagai argv terpisah.

### K7. API key plaintext saat Keystore gagal + ikut backup — **Sedang**
- Lihat `masalah/bug.md` #13. Tambahkan exclude `amaya_secure_prefs_fallback.xml` di `backup_rules.xml` dan `data_extraction_rules.xml`, atau hilangkan fallback plaintext.

### K8. `cleartextTrafficPermitted="true"` global — **Rendah/Sedang**
- **File**: `res/xml/network_security_config.xml`. Komentar menyebut `ProviderModelService` menolak HTTP publik, tetapi `McpClientManager.testServer/executeRequest` menerima `http://` apa pun (termasuk publik) dan mengirim header berisi API key MCP. Batasi cleartext ke loopback/RFC1918 lewat `<domain-config>` atau validasi host di klien MCP.

### K9. Fail-open kapabilitas agen — **Sedang**
- `ToolExecutor.assistantModeAllowsCapability(AGENT)` → profil `null` = semua tool diizinkan. Ubah default ke *deny* atau profil minimal eksplisit.

### K10. `MANAGE_EXTERNAL_STORAGE` + `requestLegacyExternalStorage` + `allowBackup=true`
- Kombinasi ini memberi tool AI akses ke seluruh storage; `MCP_FIXED_PATH=/storage/emulated/0/Amaya/mcp.json` membaca konfigurasi (dengan header rahasia) dari lokasi yang bisa ditulis aplikasi lain. Simpan `mcp.json` di `filesDir` atau verifikasi kepemilikan.

### K11. Callback OAuth Codex pada `localhost:1455/1457/1459`
- **File**: `data/remote/api/CodexAuthManager.kt`. Aplikasi lain di perangkat dapat mengirim request ke port ini. `state` diverifikasi dan PKCE melindungi penukaran kode, jadi risikonya rendah, tetapi pastikan `ServerSocket` di-bind ke `127.0.0.1` saja (bukan `0.0.0.0`) di `tryBindServer`.

---

## Ekstensi VS Code (`amaya-remote-extension/`)

### K12. WebSocket server tanpa autentikasi, bind ke semua interface — **Tinggi**
- **File**: `src/extension.ts` (`new WebSocket.Server({ port })`, handler `connection` langsung memanggil `handler.handleCommand`).
- Siapa pun di jaringan yang sama dapat: mengirim prompt ke agent IDE (memakai kuota/kredensial pengguna), menjalankan perintah workspace, membaca state dan riwayat percakapan.
- **Perbaikan**: bind ke `127.0.0.1` + pairing token (QR) yang wajib pada handshake (`verifyClient`/header `Authorization`), periksa `Origin`, rate-limit, dan tolak koneksi kedua saat belum di-pair.

### K13. Kredensial diminta lewat `showInputBox` tanpa `password: true`
- `promptCredentials()` menampilkan API key (`ya29...`) dan CSRF token dalam teks jelas. Tambahkan `{ password: true }` dan simpan di `context.secrets`.

---

## Windows Bridge (`windows-bridge/`)

### K14. Default tanpa autentikasi dan bind `0.0.0.0` — **Tinggi**
- **File**: `src/main/pairing.ts` (`AMAYA_BRIDGE_HOST || '0.0.0.0'`, `token = null`), `src/permissions/security-policy.ts` (`requireToken: false`, `allowQueryTokenFallback: true`), `src/transport/websocket-server.ts`.
- Tanpa `AMAYA_BRIDGE_TOKEN` dan tanpa file policy, bridge menerima koneksi LAN tanpa token dan dapat menggerakkan mouse/keyboard, menangkap layar, membuka aplikasi.
- Token di query string (`allowQueryTokenFallback`) bocor ke log proxy/riwayat.
- **Perbaikan**: `requireToken: true` default, buat token acak saat pertama jalan dan tampilkan QR, bind `127.0.0.1` kecuali pengguna memilih LAN, matikan query fallback.

### K15. `command-policy.ts` substring matching
- Lihat `masalah/bug.md` #19. Meskipun `shellEnabled: false` default, saat diaktifkan daftar blokir mudah dilewati (`Remove-Item`, `cmd /c del`).

---

## Ringkasan risiko

| ID | Komponen | Risiko |
|----|----------|--------|
| K1, K2, K3 | Android shell | Tinggi |
| K12 | Ekstensi | Tinggi |
| K14 | Windows Bridge | Tinggi |
| K5, K6, K7, K9 | Android | Sedang |
| K4, K8, K10, K11, K13, K15 | Campuran | Rendah–Sedang |
