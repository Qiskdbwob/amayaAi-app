# Temuan Over-Engineering & Kompleksitas Berlebih

Bukan bug, tetapi menaikkan biaya pemeliharaan, mempersulit pengujian, dan memperbesar permukaan serangan.

---

## 1. `AiAgentLoop.chatImpl` — satu fungsi ~1.000 baris
- **File**: `app/src/main/java/com/amaya/intelligence/data/repository/AiAgentLoop.kt`.
- Extension function di dalam `channelFlow` dengan >30 variabel `var` lokal (`ledger`, `taskPlan`, `verificationActive`, `failedToolAttempts`, `streamContinuations`, dst.), fungsi lokal `composeWithPlan()` yang menangkap state, dan 5 skema (C, E, verifikasi, kompaksi, circuit breaker) saling bersilang.
- **Dampak**: hampir tidak bisa diuji unit per bagian (bukti: test hanya menguji fungsi `internal` kecil seperti `shouldRunVerificationPass`), regresi mudah terjadi.
- **Saran**: pecah menjadi kelas tanpa state global: `ToolCallGate` (validasi nama/ID/argumen), `ContextCompactor` (ledger + eviction), `ToolBatchRunner` (dedup, circuit breaker, feedback), `VerificationPass`, `TurnPersistence`. `chatImpl` hanya mengorkestrasi.

## 2. Lapisan memori/self-improvement yang bertumpuk
- **File**: `domain/memory/*` (Classifier, ContentNormalizer, Deduper, SafetyFilter, Volatility, PrimedState, Recommendation, PendingProposal), `data/repository/*` (SelfImprovementPipeline, PrimedStateRepository, ProjectStateRepository, AndroidCapabilityRepository, RecommendationRepository, ContextBudgetManager, TaskLedger, TaskPlan, SessionTagger, SessionSummarizer, MemoryProposalMapper, SkillUsageLogRepository).
- Setiap fitur menambah *provider* ke `ContextManager` (PitfallIndexProvider, ProjectStateProvider, CapabilityMatrixProvider, RecommendationProvider, MemorySnapshotProvider) dan bagian prompt sistem baru. Heuristik teks (`CORRECTION_MARKERS`, marker keputusan "we chose X over Y", `isUserCorrectionMessage`) rapuh terhadap bahasa/gaya pengguna.
- **Saran**: ukur nilai tiap skema (A/B: matikan provider, bandingkan hasil). Gabungkan ProjectState + Recommendation + PrimedState menjadi satu "workspace notes" sederhana; simpan hanya yang terbukti dipakai model.

## 3. Validasi perintah berlapis tetapi tidak konsisten
- `ToolExecutor` → `CommandValidator.validateToolCall` → `validateCommand`; lalu `RunShellTool.execute` → `validateCommand` **lagi**; `HARD_BLOCK_PATTERNS` dievaluasi dua kali (`validateCommand` dan `isNonDestructiveCommand`). Di sisi lain, `WorkspacePathResolver` dan `validatePath` mengimplementasikan traversal check dengan aturan berbeda.
- **Saran**: satu pipeline validasi (resolve → policy → decision) yang dipanggil sekali; tool menerima keputusan final via `ToolExecutionContext`.

## 4. Ekstensi VS Code: 12 controller untuk satu WebSocket handler
- **File**: `amaya-remote-extension/src/controllers/MessageHandler.ts` + `support/*` (StreamOrchestrator, MessageFlowController, MessageLifecycleController, MessageCommandRouter, ConversationStateController, WorkspaceCommandController, EventBuffer, UiMessageProjector, AttachmentValidator, ModelQuotaGuard, ErrorMessageFormatter, HostWorkspaceService).
- Setiap controller menerima 6–10 lambda (`broadcastEvent`, `sendToClient`, `getModelsCache`, `setModelsCache`, ...) yang diteruskan berulang; ini adalah *dependency passing manual* tanpa manfaat DI. Komentar "Modular OOP Architecture" menegaskan tujuan struktural, bukan kebutuhan.
- **Saran**: satu objek `HandlerContext` (api, state, bus) yang dibagikan; atau event emitter. Kurangi menjadi 3–4 modul (transport, session, stream, commands).

## 5. Tiga runtime remote yang "deferred" tetap dikirim di APK
- `impl/ide/{antigravity,cursor,windsurf,opencode}`, `impl/bridge/windows/*`, `ui/activities/{antigravity,opencode,bridge}`, dependensi `Java-WebSocket`, CameraX + ML Kit (QR), Guava.
- `app/AGENTS.md` menyatakan semuanya "incomplete/deferred; do not optimize". Kode ini menambah ukuran APK, izin (`CAMERA`), dan permukaan serangan tanpa nilai bagi pengguna saat ini.
- **Saran**: pindahkan ke Gradle *feature module* / product flavor `remote`, atau hapus dari `main` sampai diaktifkan kembali.

## 6. `LinuxSandboxManager` 1.000+ baris, tanggung jawab campuran
- Unduh + progress, ekstraksi tar, parsing header ELF manual (`extractEmbeddedLoader`), provisioning DNS/hosts dengan IP mirror hardcoded, penulisan repo apk, eksekusi proses, penyembuhan symlink/permission.
- IP statis Fastly/kernel.org di kode akan basi. **Saran**: pisahkan `SandboxInstaller`, `SandboxRuntime`, `GuestNetworkProvisioner`; simpan mirror di resource yang mudah diperbarui; hilangkan parsing ELF dengan selalu mem-bundle loader sebagai jniLib (sudah dilakukan) dan buang jalur fallback.

## 7. Skrip Gradle: tiga tingkat fallback debug keystore + task `ensureDebugKeystore`
- **File**: `app/build.gradle.kts`.
- AGP sudah otomatis membuat `~/.android/debug.keystore` saat tidak ada. Task kustom yang menjalankan `keytool` via `ProcessBuilder` + `afterEvaluate { tasks.matching { name.startsWith("validateSigning") ... } }` rapuh terhadap perubahan nama task AGP.
- **Saran**: hapus `signingConfigs.debugConfig` kustom; biarkan default. Untuk CI, cukup `android-actions/setup-android`.

## 8. Enam utilitas logging paralel
- `util/LogUtils.kt`, `util/ToolDebugLog.kt`, `util/LocalStreamPerfLog.kt`, `data/repository/AiRepository` `StreamDebugLog`, `impl/ide/antigravity/services/AntigravityRemoteDebugLog.kt`, `impl/bridge/windows/WindowsBridgeLogger.kt`.
- **Saran**: satu fasad logging dengan *tag* dan *level*, redaksi terpusat.

## 9. Aliasing argumen tool yang terlalu permisif
- `WorkspacePathResolver` menerima `path|file_path|filePath|file|target_file|TargetFile`; `RunShellTool` menerima `command|cmd`, `timeout_ms|timeout_seconds|timeout`; `WebSearchTool` menerima `query|q|search`, `urls|links`. Ini menutupi kesalahan model alih-alih memaksa skema yang diiklankan, dan membuat validator (`missingToolTarget` hanya memeriksa `path`) tidak sinkron.
- **Saran**: normalisasi alias di **satu** tempat sebelum validasi, atau tolak alias dan berikan feedback ke model.

## 10. Dokumentasi `AGENTS.md` per-direktori yang sangat panjang
- `app/AGENTS.md` berisi paragraf tunggal ratusan kata yang mendeskripsikan perilaku runtime detail (durasi thinking, warna kartu, skema notifikasi). Ini adalah *spec* yang cepat basi dan duplikat dari kode.
- **Saran**: batasi AGENTS.md pada aturan (do/don't) dan tautan; pindahkan spesifikasi ke `docs/` yang di-versi.
