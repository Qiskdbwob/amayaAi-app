# Saran Improvement (Arsitektur, Tooling, Kualitas)

Bersifat jangka menengah; melengkapi `saran/perbaikan.md` yang fokus pada perbaikan langsung.

---

## 1. Pipeline GitLab CI

Repo ini hidup di GitLab tetapi hanya memiliki GitHub Actions. Contoh minimal `.gitlab-ci.yml`:

```yaml
stages: [build, test, security]

variables:
  GRADLE_OPTS: "-Dorg.gradle.daemon=false"
  GRADLE_USER_HOME: "$CI_PROJECT_DIR/.gradle"

cache:
  key: gradle-$CI_COMMIT_REF_SLUG
  paths: [.gradle/caches, .gradle/wrapper]

build:perf:
  stage: build
  image: mobiledevops/android-sdk-image:34.0.0
  script:
    - ./gradlew :app:assemblePerf --stacktrace
  artifacts:
    paths: [app/build/outputs/apk/perf/*.apk]
    expire_in: 7 days

test:unit:
  stage: test
  image: mobiledevops/android-sdk-image:34.0.0
  script:
    - ./gradlew :app:testPerfUnitTest --stacktrace
  artifacts:
    when: always
    reports:
      junit: app/build/test-results/testPerfUnitTest/*.xml

test:extension:
  stage: test
  image: node:20
  script:
    - cd amaya-remote-extension && npm ci && npx tsc --noEmit

test:bridge:
  stage: test
  image: node:20
  script:
    - cd windows-bridge && npm ci && npm run typecheck

include:
  - template: Security/SAST.gitlab-ci.yml
  - template: Security/Secret-Detection.gitlab-ci.yml
  - template: Security/Dependency-Scanning.gitlab-ci.yml
```

Manfaat langsung: Secret Detection akan menandai fixture berisi PII/token, Dependency Scanning menangkap `security-crypto` alpha dan versi lama.

## 2. Static analysis
- Android: tambahkan `detekt` + `ktlint` dengan baseline; aktifkan `lint { abortOnError = true }` untuk `perf`.
- TypeScript: `eslint` + `@typescript-eslint/no-floating-promises`, `strict: true` di kedua `tsconfig.json`.
- C#: `dotnet format --verify-no-changes` untuk `native-helper`.

## 3. Modularisasi Gradle
- `:core:security` (CommandValidator, WorkspacePathResolver, ToolTargetPolicy) — murni JVM, tanpa Android, agar test cepat dan dapat dipakai ulang.
- `:core:sandbox` (LinuxSandboxManager).
- `:feature:remote` (antigravity/opencode/cursor/windsurf + QR + WebSocket) dan `:feature:bridge` sebagai *dynamic feature* atau flavor `remote`. Build default (`local`) tidak menyertakan CameraX/ML Kit/Java-WebSocket → APK lebih kecil, izin `CAMERA` hilang.

## 4. Refactor `AiAgentLoop` menjadi state machine
- Representasikan turn sebagai `sealed interface TurnState { Requesting, ExecutingTools, Verifying, Compacting, Done, Failed }` dengan reducer murni yang diuji tanpa provider nyata (fake `AiProvider` yang mengembalikan skrip event).
- Pindahkan heuristik teks (`isUserCorrectionMessage`, marker keputusan) ke satu `TextSignals` object dengan test tabel bahasa ID/EN.

## 5. Kebijakan perintah berbasis allowlist yang dapat dikonfigurasi
- Ganti `HARD_BLOCK` + `DANGEROUS_VERBS` dengan tabel `CommandRule(pattern, decision, reason)` yang dimuat dari resource JSON (bisa diperbarui tanpa release) dan diuji dengan corpus perintah (`docs/security/command-corpus.txt`).
- Tampilkan alasan keputusan ke pengguna di dialog approval (sudah ada `reason`), tambahkan tombol "Selalu tolak pola ini".

## 6. Observabilitas
- Satu fasad `AmayaLog` dengan `LogSink` (Logcat di debug, ring buffer + ekspor file di release). Redaksi rahasia terpusat (API key, path absolut).
- Ekspor `StreamDebugLog` sebagai NDJSON yang bisa diunggah ke issue.

## 7. Web search
- Regex HTML terhadap DuckDuckGo/Bing rapuh. Gunakan `jsoup` (sudah umum di Android) untuk parsing, atau API resmi (SearXNG self-host / Brave Search API) dengan kunci opsional dari pengguna.

## 8. Dependensi
- Aktifkan Renovate (`renovate.json`) dengan grup Kotlin/Compose/Room.
- `geckoview-omni` (~100 MB) hanya untuk fitur browser: jadikan *dynamic feature* atau unduh on-demand.

## 9. Dokumentasi
- Pindahkan spesifikasi perilaku dari `AGENTS.md` ke `docs/spec/*.md` yang di-versi; `AGENTS.md` hanya aturan singkat + tautan.
- Tambahkan `SECURITY.md` (model ancaman: tool AI = pengguna tidak tepercaya di perangkat; kebijakan approval; cara melapor).
- Tambahkan ADR (`docs/adr/0001-targetsdk-28.md`) untuk keputusan `targetSdk 28` dan rencana keluar.

## 10. Pengujian end-to-end
- Gunakan `DebugActivity` yang sudah ada sebagai basis test instrumentasi (`androidTest`) di emulator CI untuk skenario: approval, sandbox off/on, containment.
- Untuk ekstensi/bridge: test integrasi WebSocket dengan `ws` mock client yang memverifikasi penolakan koneksi tanpa token.
