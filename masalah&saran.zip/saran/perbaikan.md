# Saran Perbaikan (Prioritas & Langkah Konkret)

Urutan berdasarkan dampak. Setiap langkah dapat menjadi satu MR kecil.

---

## Sprint 1 — Keamanan shell (Android)

1. **Cocokkan pola trusted per segmen.** Di `TerminalSettingsRepository.commandMatchesWildcard`, ubah `*` → `[^;&|\n]*` dan di `CommandValidator.validateCommand` pecah perintah dengan `Regex("\\s*(?:;|&&|\\|\\||\\||&|\\n)\\s*")`, lalu setiap segmen harus (a) cocok trusted **atau** (b) lolos `isNonDestructiveCommand`. Tambahkan unit test: `ls && rm -rf ./x`, `find . -delete`, `cat a; git push`.
2. **Satu sumber kebenaran untuk status sandbox.** Tambahkan `LinuxSandboxManager.isExecutable()` (rootfs + PRoot tersedia). Pakai di `RunShellTool` dan teruskan ke `CommandValidator.validateToolCall(sandboxActive = ...)` menggantikan `terminalSettings.useLinuxSandbox`. Jika setting ON tetapi tidak executable → kembalikan `ToolResult.Error(SECURITY_VIOLATION)` yang jelas.
3. **Perluas daftar *requires review*.** Tambahkan interpreter dan package manager: `python|python3|node|deno|bun|perl|ruby|php|sh|bash|ash|zsh|eval|source|xargs|cp|install|patch|npm|npx|yarn|pnpm|pip|pip3|apk|gradle|gradlew|make|cmake`. Deteksi `sed -i`/`perl -i`. Perbarui `TerminalSettingsScreen` agar pengguna tahu perubahan ini.
4. **Lengkapi `shellWorkspaceViolation`.** Resolve token relatif yang mengandung `..`, tolak `~`/`$HOME`/`${...}`, tangani `cd\t`, `pushd`, `cd -`. Pindahkan pemecahan segmen ke helper bersama dengan `isEffectfulGitCommand`.
5. **Perbaiki `HARD_BLOCK_PATTERNS`.** Tambah `(^|[;&|]\s*)(sh|bash|ash|dash|zsh)\s+-c\b`, `\beval\b`, `\bsource\b`, `chmod\s+(-R\s+)?(0?777|a\+rwx|[ugo]*\+s)`. Ganti penanda `>` dengan regex yang mengabaikan `2>&1`/`&>`.

## Sprint 2 — Penyimpanan & integritas

6. **Backup rules.** Tambahkan `<exclude domain="sharedpref" path="amaya_secure_prefs_fallback.xml"/>` di `backup_rules.xml` dan `data_extraction_rules.xml`. Lebih baik: hapus fallback plaintext; tampilkan state "Secure storage unavailable" dan minta pengguna memasukkan ulang kredensial per sesi.
7. **Verifikasi hash unduhan sandbox.** Pin SHA-256 rootfs (per `ALPINE_VERSION`/arsitektur) dan PRoot di `LinuxArchitecture`. Verifikasi sebelum `extractTarGz`. Hapus mirror `http://`.
8. **Zip-Slip.** `if (!targetFile.canonicalPath.startsWith(destDir.canonicalPath + File.separator))`.
9. **`runApkAdd`.** Validasi `packageName` dengan `Regex("^[a-z0-9._+-]+( [a-z0-9._+-]+)*$")` atau kirim sebagai argumen terpisah.
10. **Room.** Tambahkan `fallbackToDestructiveMigrationFrom(1, 2, 3, 4)` atau migrasi eksplisit.

## Sprint 3 — Agent loop

11. Hapus `rejectedToolCalls` dan jalurnya; **jangan** kirim `AgentEvent.ToolCallStart` untuk tool yang tidak dikenali — kirim `ToolCallResult(isError=true)` langsung.
12. Reset `failedToolAttempts` setelah batch tool call sukses; perbaiki pesan.
13. `synth_call_` → `UUID.randomUUID()`.
14. Simpan hasil `validateToolArguments` sekali.
15. `RunShellTool`: hapus catch `TimeoutCancellationException`; jadikan `truncated` `@Volatile` atau kembalikan hasil dari reader thread lewat `CompletableDeferred`; panggil `getSettings()` sekali dan teruskan; perbaiki deskripsi ("blacklist + review").
16. `ToolExecutor`: default `agentCapabilityProfile == null` → profil minimal (read-only), bukan `true`; cache `integerNames` per tool; hapus `desanitizeBridgeToolName`.

## Sprint 4 — Remote/bridge (jika komponen ini dipertahankan)

17. **Ekstensi**: `new WebSocket.Server({ host: '127.0.0.1', port, verifyClient })` dengan token pairing yang dibuat acak (`crypto.randomBytes`), ditampilkan sebagai QR oleh `ConnectivityManager.showConnectionInfo`. Simpan API key di `context.secrets`; `showInputBox({ password: true })`.
18. **Windows Bridge**: default `requireToken: true`, `allowQueryTokenFallback: false`, host `127.0.0.1`; buat token saat pertama jalan dan simpan di `PairingTokenStore`. Ubah `command-policy.ts` ke tokenisasi + word boundary.

## Sprint 5 — Build, CI, repo hygiene

19. Tambahkan `.gitlab-ci.yml` (contoh di `saran/improvement.md`). Commit `gradle/wrapper/gradle-wrapper.jar`.
20. Pindahkan semua versi ke `libs.versions.toml`; naikkan `security-crypto` ke `1.1.0` stabil; samakan `kotlin-test`/`coroutines-test` dengan versi plugin.
21. Hapus izin Bluetooth; hapus `jniLibs/x86/libproot_loader.so`; hapus `tools:targetApi="34"` atau sesuaikan.
22. Isi `LICENSE` (Apache-2.0 penuh) dan `AGENTS.md` root; hapus referensi ke `docs/local/*` atau un-ignore dokumen yang dirujuk.
23. Anonimkan `user-status-response.json`; hapus `tmp_*.js`, `raw-cortex-capture copy.json`, `walkthrough.md.resolved`; pertimbangkan `git filter-repo`.
24. Bersihkan `.gitignore` dari nama file scratch; gunakan `.git/info/exclude`.

---

## Daftar test yang perlu ditambahkan

| Area | Test |
|------|------|
| `CommandPolicyTest` | `ls && rm -rf ./x` → RequiresConfirmation; `find . -delete` → RequiresConfirmation; `python -c ...` → RequiresConfirmation; `cd ../..` → Denied; `cat ../../etc/hosts` → Denied |
| `LinuxSandboxTest` | `isExecutable()` false saat PRoot hilang; Zip-Slip `alpine2/` ditolak; hash mismatch → install gagal |
| `AiToolArgumentValidatorTest` | tool tidak dikenal tidak menghasilkan `ToolCallStart` |
| `ToolExecutor` | profil agen null → tool destruktif ditolak |
| Backup | lint/skrip yang memastikan semua pref berisi kredensial ada di exclude list |
| Ekstensi | koneksi tanpa token ditutup dengan code 1008 |
